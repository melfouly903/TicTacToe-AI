import tkinter as tk  # Import tkinter for GUI components
from tkinter import messagebox  # Import messagebox for displaying game results (win, tie)
import pygame  # Import pygame for playing sound effects
from minimax_algorithm import minimax  # Import minimax algorithm for AI moves
from minimax_heuristic_algorithm import minimax_with_heuristic  # Import minimax with heuristic
from alpha_beta_algorithm import alpha_beta_pruning  # Import minimax with alpha-beta pruning
from symmetry_reduction_algorithm import symmetry_reduction  # Import symmetry reduction algorithm
from heuristic_reduction_algorithm import heuristic_reduction  # Import heuristic reduction algorithm
from alpha_beta_heuristic_algorithm import alpha_beta_with_heuristic  # Import alpha-beta with heuristic

pygame.init()  # Initialize pygame for sound functionalities
  
class TicTacToe:
    def __init__(self, master):

        # Initialize the main window and set its properties
        self.master = master
        self.master.title("Tic Tac Toe")
        self.master.configure(bg="gray20")

        # Initialize the game board as a list of 9 empty spaces
        self.board = [" " for _ in range(9)] # _ means we don't need to use the index
        self.current_player = "X"  # X always starts
        self.ai_algorithm = None  # Selected AI algorithm
        self.score_x = 0  # Score for player X
        self.score_o = 0  # Score for player O

        # Score display label
        self.score_label = tk.Label(
            self.master,
            text=f"Player X: {self.score_x} | Player O: {self.score_o}",
            bg="black",
            fg="white",
            font=("Segoe UI", 18)
        )
        self.score_label.grid(row=0, column=0, columnspan=3, pady=10)

        # Create 3x3 grid of buttons for the game board
        self.buttons = []
        for i in range(3):
            for j in range(3):
                button = tk.Button(
                    self.master,
                    text="",
                    font=("Segoe UI", 18),
                    width=6,
                    height=2,
                    command=lambda row=i, col=j: self.make_move(row, col),  # Pass row and col to make_move
                    bg='black',
                    fg='white'
                )
                button.grid(row=i + 1, column=j) # GRID method is used to place the button SIZE AND POSITION
                self.buttons.append(button)

        # Dropdown menu for selecting AI algorithm
        self.algorithm_var = tk.StringVar()
        self.algorithm_var.set("Choose Algorithm")
        algorithms = [
            "Minimax",
            "Minimax with Heuristic",
            "Alpha-Beta Pruning",
            "Alpha-Beta with Heuristic",
            "Symmetry Reduction",
            "Heuristic Reduction"
        ]
        algorithm_menu = tk.OptionMenu( # IT IS USED TO CREATE A DROPDOWN MENU
            self.master, #MASTER MEANS THE MAIN WINDOW
            self.algorithm_var, # Variable to hold the selected algorithm
            *algorithms, # * MEANS UNPACKING THE LIST OF ALGORITHMS
            command=self.select_algorithm  # Callback when selection changes
        )
        algorithm_menu.configure(bg="gray20", fg="white", highlightbackground="black")
        algorithm_menu.grid(row=4, column=0, columnspan=3, pady=10) # SIZE OF THE DROPDOWN MENU

        # Reset button to restart the game and scores
        reset_button = tk.Button(
            self.master, # CALLING THE MASTER WINDOW FOR THE BUTTON TO BE PLACED
            text="Reset Game",
            command=self.reset_game, 
            bg="gray20",
            fg="white"
        )
        reset_button.grid(row=5, column=0, columnspan=3, pady=10)

    def select_algorithm(self, algorithm):
        # Set the selected AI algorithm
        self.ai_algorithm = algorithm

    def make_move(self, row, col): # we sent the row and col because we need to know which button was pressed self means the class
        # Handle a player's move at the given row and column
        index = row * 3 + col
        if self.board[index] == " ": # if empty
            self.board[index] = self.current_player  # Update board state with current player's symbol
            color = "red" if self.current_player == "X" else "blue" # Set color based on player
            self.buttons[index].config(text=self.current_player, state=tk.DISABLED, fg=color)  # this line disables the button from being pressed again
            if self.check_winner():
                # If current player wins, show message, play sound, update score, and reset board
                messagebox.showinfo("Game Over", f"Player {self.current_player} wins!")
                self.play_sound("win")
                self.update_score()
                self.reset_board()
            elif " " not in self.board: #  " " mean in this line that the board is full
                # If board is full and no winner, it's a tie
                messagebox.showinfo("Game Over", "It's a tie!")
                self.play_sound("tie")
                self.reset_board()
            else:
                # Switch to the next player
                self.switch_player()
                # If it's AI's turn, make the computer move
                if self.current_player == "O" and self.ai_algorithm:
                    self.computer_move()

    def computer_move(self):
        # Call the selected AI algorithm to determine the best move for the computer
        if self.ai_algorithm == "Minimax":
            self.move(minimax)
        elif self.ai_algorithm == "Minimax with Heuristic":
            self.move(minimax_with_heuristic)
        elif self.ai_algorithm == "Alpha-Beta Pruning":
            self.move(alpha_beta_pruning)
        elif self.ai_algorithm == "Alpha-Beta with Heuristic":
            self.move(alpha_beta_with_heuristic)
        elif self.ai_algorithm == "Symmetry Reduction":
            self.move(symmetry_reduction)
        elif self.ai_algorithm == "Heuristic Reduction":
            self.move(heuristic_reduction)

    def move(self, algorithm): # this function is used to call the algorithm
        # Use the given algorithm to get the best move index for "O"
        best_move = algorithm(self.board, "O")
        # Make the move after a short delay for better UX
        self.master.after(500, lambda: self.make_move(best_move // 3, best_move % 3)) # this line is used to convert the index to row and column

    def highlight_winner(self, combo): # combo means the winning combination
        # Highlight the winning combination with a blinking effect
        color = "red" if self.current_player == "X" else "blue"
        original_color = "black"

        def blink(count=0): # Recursive function to create a blinking effect
            for index in combo:
                if count % 2 == 0:
                    self.buttons[index].config(bg=color)
                else:
                    self.buttons[index].config(bg=original_color)
            if count < 5:
                self.master.after(300, blink, count + 1)

        blink()

    def check_winner(self):
        # Check if there is a winner on the board
        winning_combinations = [
            (0, 1, 2), (3, 4, 5), (6, 7, 8),  # Rows
            (0, 3, 6), (1, 4, 7), (2, 5, 8),  # Columns
            (0, 4, 8), (2, 4, 6)              # Diagonals
        ]
        for combo in winning_combinations:
            if self.board[combo[0]] == self.board[combo[1]] == self.board[combo[2]] != " ":
                self.highlight_winner(combo)
                return True
        return False

    def switch_player(self):
        # Switch the current player from X to O or O to X
        self.current_player = "O" if self.current_player == "X" else "X"

    def update_score(self):
        # Update the score for the winning player
        if self.current_player == "X":
            self.score_x += 1
        elif self.current_player == "O":
            self.score_o += 1
        self.score_label.config(text=f"Player X: {self.score_x} | Player O: {self.score_o}")

    def reset_board(self):
        # Reset the board for a new round, but keep the scores
        for i in range(9):
            self.board[i] = " "
            self.buttons[i].config(text="", state=tk.NORMAL, fg="white", bg="black")
        self.current_player = "X"

    def reset_game(self):
        # Reset the board and scores for a completely new game
        self.reset_board()
        self.score_x = 0
        self.score_o = 0
        self.score_label.config(text=f"Player X: {self.score_x} | Player O: {self.score_o}")

    def play_sound(self, sound_type):
        # Play a sound based on the game result (win or tie)
        if sound_type == "win":
            sound_file = "win_sound.wav"
        elif sound_type == "tie":
            sound_file = "tie_sound.wav"
        else:
            return

        pygame.mixer.music.load(sound_file)
        pygame.mixer.music.play()

if __name__ == "__main__": #
    # Start the Tkinter main loop and launch the game
    root = tk.Tk()# Create the main window
    app = TicTacToe(root) # Create an instance of the TicTacToe class
    root.mainloop() # Start the Tkinter event loop
