# Cache for memoization to avoid redundant calculations of board states
memoization_cache = {}

def symmetry_reduction(board, player):
    """
    Finds the best move for the current player using symmetry reduction.
    It evaluates all symmetrical transformations of the board to avoid redundant calculations.
    """
    best_move = get_random_move(board)  # Default move if no better found
    best_score = float("-inf")  # Initialize best score - MEANING: worst case

    # Iterate over all possible symmetries (rotations/reflections)
    for transformation in get_symmetries():
        # Apply the symmetry transformation to the board
        transformed_board = apply_symmetry(board, transformation)
        # Evaluate the board using minimax with symmetry reduction
        score = minimax_with_symmetry_reduction(transformed_board, player)

        # If this transformation yields a better score, update best_move and best_score
        if score > best_score:
            best_score = score
            # Convert the move back to the original board's coordinates
            best_move = reverse_symmetry_move(best_move, transformation)

    return best_move

def get_canonical_form(board):
    """
    Returns the canonical (minimum) string representation of the board
    among all its symmetrical forms. Used for memoization.
    """
    # Generate all symmetrical forms of the board
    symmetries = [apply_symmetry(board, t) for t in get_symmetries()]
    # Convert each board to a string for comparison
    forms = [''.join(sym) for sym in symmetries]
    # Return the lexicographically smallest form
    return min(forms)

def minimax_with_symmetry_reduction(board, player):
    """
    Minimax algorithm with symmetry reduction and memoization.
    Evaluates the board and returns the best score for the current player.
    """
    # Get the canonical form for memoization
    canonical = get_canonical_form(board)
    if canonical in memoization_cache:
        return memoization_cache[canonical]

    # Find all available moves (empty spaces)
    available_moves = [i for i in range(9) if board[i] == " "]
    # Check for terminal states (win/loss/draw)
    if check_winner(board, "X"):
        return -1  # X wins
    elif check_winner(board, "O"):
        return 1   # O wins
    elif not available_moves:
        return 0   # Draw

    # Initialize best_score depending on the player
    best_score = float("-inf") if player == "O" else float("inf")
    # Try all possible moves
    for move in available_moves:
        board[move] = player  # Make the move
        # Recursively evaluate the resulting board
        score = minimax_with_symmetry_reduction(board, "X" if player == "O" else "O")
        board[move] = " "     # Undo the move

        # Update best_score based on the player
        if player == "O":
            best_score = max(best_score, score)
        else:
            best_score = min(best_score, score)

    # Cache the result for this canonical board
    memoization_cache[canonical] = best_score
    return best_score

def apply_symmetry(board, transformation):
    """
    Applies a symmetry transformation to the board.
    'transformation' is a list mapping old indices to new indices.
    Returns the transformed board as a list.
    """
    transformed = [" "] * 9
    for i in range(9):
        transformed[transformation[i]] = board[i]
    return transformed

def reverse_symmetry_move(move, transformation):
    """
    Given a move index and a transformation, returns the original move index
    before the transformation was applied.
    """
    # Build the inverse transformation
    inverse = [0] * 9
    for i, j in enumerate(transformation):
        inverse[j] = i
    return inverse[move]

def get_symmetries():
    """
    Returns a list of all 8 symmetry transformations for a 3x3 board:
    identity, 3 rotations, and 4 reflections.
    Each transformation is a list mapping old indices to new indices.
    """
    return [
        [0,1,2,3,4,5,6,7,8],  # identity
        [6,3,0,7,4,1,8,5,2],  # rotate 90
        [8,7,6,5,4,3,2,1,0],  # rotate 180
        [2,5,8,1,4,7,0,3,6],  # rotate 270
        [2,1,0,5,4,3,8,7,6],  # horizontal reflection
        [6,7,8,3,4,5,0,1,2],  # vertical reflection
        [0,3,6,1,4,7,2,5,8],  # main diagonal
        [8,5,2,7,4,1,6,3,0],  # anti-diagonal
    ]

def check_winner(board, player):
    """
    Checks if the given player has won on the board.
    Returns True if the player has a winning combination, else False.
    """
    win_combinations = [
        (0,1,2), (3,4,5), (6,7,8),  # rows
        (0,3,6), (1,4,7), (2,5,8),  # columns
        (0,4,8), (2,4,6)            # diagonals
    ]
    return any(all(board[i] == player for i in combo) for combo in win_combinations)

def get_random_move(board):
    """
    Returns the index of the first available move (empty space) on the board.
    """
    return board.index(" ")
