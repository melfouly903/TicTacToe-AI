# alpha_beta_heuristic_algorithm.py

# Main function implementing alpha-beta pruning with a heuristic for Tic-Tac-Toe
def alpha_beta_with_heuristic(board, player, alpha=float("-inf"), beta=float("inf")):
    # Get all available moves (empty positions on the board)
    available_moves = [i for i in range(9) if board[i] == " "]

    # Base cases for terminal states: check if game is over
    if check_winner(board, "X"):
        return -1  # X wins, unfavorable for O
    elif check_winner(board, "O"):
        return 1   # O wins, favorable for O
    elif not available_moves:
        return 0   # Draw

    best_move = None  # Track the best move found

    # Maximizing player (O)
    if player == "O":
        best_score = float("-inf")
        for move in available_moves:
            board[move] = player  # Make the move
            heuristic_score = evaluate(board, player)  # Evaluate board after move
            # Recursively call for the minimizing player (X)
            score = heuristic_score + alpha_beta_with_heuristic(board, "X", alpha, beta)
            board[move] = " "  # Undo the move
            if score > best_score:
                best_score = score
                best_move = move
            alpha = max(alpha, best_score)  # Update alpha
            if alpha >= beta:
                break  # Beta cutoff (prune branch)

    # Minimizing player (X)
    else:
        best_score = float("inf")
        for move in available_moves:
            board[move] = player  # Make the move
            heuristic_score = evaluate(board, player)  # Evaluate board after move
            # Recursively call for the maximizing player (O)
            score = heuristic_score + alpha_beta_with_heuristic(board, "O", alpha, beta)
            board[move] = " "  # Undo the move
            if score < best_score:
                best_score = score
                best_move = move
            beta = min(beta, best_score)  # Update beta
            if alpha >= beta:
                break  # Alpha cutoff (prune branch)

    # Return the best score if no move found (terminal), else return the best move
    return best_score if best_move is None else best_move


# Helper function to check if a player has won
def check_winner(board, player):
    # All possible winning combinations in Tic-Tac-Toe
    winning_combinations = [
        (0, 1, 2), (3, 4, 5), (6, 7, 8),  # Rows
        (0, 3, 6), (1, 4, 7), (2, 5, 8),  # Columns
        (0, 4, 8), (2, 4, 6)              # Diagonals
    ]

    # Check if any winning combination is filled by the player
    for combo in winning_combinations:
        if board[combo[0]] == board[combo[1]] == board[combo[2]] == player:
            return True
    return False


# Heuristic evaluation function for the board state
def evaluate(board, player):
    # Simple heuristic: count lines where player or opponent is close to winning
    score = 0
    # All possible winning combinations
    winning_combinations = [
        (0, 1, 2), (3, 4, 5), (6, 7, 8),  # Rows
        (0, 3, 6), (1, 4, 7), (2, 5, 8),  # Columns
        (0, 4, 8), (2, 4, 6)              # Diagonals
    ]

    for combo in winning_combinations:
        # Count how many positions in the combo are occupied by the player
        player_count = sum(1 for i in combo if board[i] == player)
        # Count how many positions are occupied by the opponent
        opponent_count = sum(1 for i in combo if board[i] != " " and board[i] != player)

        # If player has two in a line and opponent has none, it's a good opportunity
        if player_count == 2 and opponent_count == 0:
            score += 10  # Favorable for player
        # If opponent has two in a line and player has none, it's a threat
        elif opponent_count == 2 and player_count == 0:
            score -= 10  # Unfavorable for player

    return score
