def heuristic_reduction(board, player): # "heuristic evaluation function
    """
    Apply heuristic reduction to choose the best move for the player.
    The function simulates each possible move, evaluates the resulting board,
    and selects the move with the highest score based on the heuristic.
    Prioritizes:
    - Winning moves
    - Blocking opponent's winning moves
    - Center position
    - Corners
    - Sides
    """
    best_move = None  # Store the best move found
    best_score = float("-inf")  # Initialize best score to negative infinity

    # Iterate through all available moves
    for move in get_available_moves(board):
        board[move] = player  # Simulate the move for the player
        score = evaluate(board, player)  # Evaluate the board after the move
        board[move] = " "  # Undo the move to restore the board

        # Update best move if this move has a higher score
        if score > best_score:
            best_score = score
            best_move = move

    return best_move  # Return the move with the highest score


def evaluate(board, player):
    """
    Evaluate the board state using a heuristic scoring system:
    - Winning moves for the player: +10
    - Blocking opponent's winning move: +8
    - Center position (index 4): +5
    - Corners (indices 0, 2, 6, 8): +3 each
    - Sides (indices 1, 3, 5, 7): +1 each
    Returns the total score for the current board state.
    """
    opponent = get_opponent(player)  # Get the opponent's symbol

    # Check if the player can win with the next move
    if is_win_move_required(board, player):
        return 10

    # Check if the opponent can win with their next move (block required)
    if is_blocking_move_required(board, opponent):
        return 8

    # Score for center position if available
    center_score = 5 if board[4] == " " else 0

    # Score for available corners
    corner_score = sum(3 for i in [0, 2, 6, 8] if board[i] == " ") # 3 points for each corner

    # Score for available sides
    side_score = sum(1 for i in [1, 3, 5, 7] if board[i] == " ") # 1 point for each side

    # Total heuristic score
    return center_score + corner_score + side_score + 0  


def is_blocking_move_required(board, opponent):
    """
    Check if the opponent has a potential winning move.
    Simulate each available move for the opponent and check if it results in a win.
    Returns True if blocking is required, otherwise False.
    """
    for move in get_available_moves(board):
        board[move] = opponent  # Simulate opponent's move
        if check_winner(board, opponent):  # Check if opponent wins
            board[move] = " "  # Undo the move
            return True  # Blocking is required
        board[move] = " "  # Undo the move
    return False  # No blocking required


def is_win_move_required(board, player):
    """
    Check if the player has a potential winning move.
    Simulate each available move for the player and check if it results in a win.
    Returns True if a winning move is available, otherwise False.
    """
    for move in get_available_moves(board):
        board[move] = player  # Simulate player's move
        if check_winner(board, player):  # Check if player wins
            board[move] = " "  # Undo the move
            return True  # Winning move is available
        board[move] = " "  # Undo the move
    return False  # No winning move available


def get_available_moves(board):
    """
    Get a list of available (empty) moves on the board.
    Returns a list of indices where the board cell is empty (" ").
    """
    return [i for i in range(9) if board[i] == " "]


def check_winner(board, player):
    """
    Check if the current player has won the game.
    Returns True if the player has any winning combination, otherwise False.
    """
    winning_combinations = [
        (0, 1, 2), (3, 4, 5), (6, 7, 8),  # Rows
        (0, 3, 6), (1, 4, 7), (2, 5, 8),  # Columns
        (0, 4, 8), (2, 4, 6)  # Diagonals
    ]

    # Check each winning combination
    for combo in winning_combinations:
        if all(board[i] == player for i in combo): # Check if all positions in the combination are occupied by the player
            return True  # Player has won
    return False  # No winning combination found


def get_opponent(player):
    """
    Return the opponent's symbol.
    If player is "O", return "X". Otherwise, return "O".
    """
    return "X" if player == "O" else "O" # the player is the always the maximizing player
