def minimax(board, player):
    # Get a list of available moves (empty spots on the board)
    available_moves = [i for i in range(9) if board[i] == " "]

    # Base case: check if "X" has won
    if check_winner(board, "X"):
        return -1  # Return -1 if "X" wins (minimizing player)
    # Base case: check if "O" has won
    elif check_winner(board, "O"):
        return 1   # Return 1 if "O" wins (maximizing player)
    # Base case: check if there are no more moves (draw)
    elif not available_moves:
        return 0   # Return 0 for a draw

    best_move = None  # To keep track of the best move found

    if player == "O":  # Maximizing player
        best_score = float("-inf")  # Initialize best score to negative infinity
        for move in available_moves:
            board[move] = player  # Place "O" on the board at the current move
            score = minimax(board, "X")  # Recursively call minimax for the opponent ("X")
            board[move] = " "  # Undo the move (backtrack)
            if score > best_score:  # If the score is better than the current best
                best_score = score  # Update best score
                best_move = move    # Update best move
    else:  # Minimizing player ("X")
        best_score = float("inf")  # Initialize best score to positive infinity
        for move in available_moves:
            board[move] = player  # Place "X" on the board at the current move
            score = minimax(board, "O")  # Recursively call minimax for the opponent ("O")
            board[move] = " "  # Undo the move (backtrack)
            if score < best_score:  # If the score is lower than the current best
                best_score = score  # Update best score
                best_move = move    # Update best move

    return best_move  # Return the best move found

def check_winner(board, player):
    # All possible winning combinations (rows, columns, diagonals)
    winning_combinations = [
        (0, 1, 2), (3, 4, 5), (6, 7, 8),  # Rows
        (0, 3, 6), (1, 4, 7), (2, 5, 8),  # Columns
        (0, 4, 8), (2, 4, 6)              # Diagonals
    ]

    # Check if any winning combination is filled by the same player
    for combo in winning_combinations:
        if board[combo[0]] == board[combo[1]] == board[combo[2]] == player:
            return True  # Player has won
    return False  # No winner found
