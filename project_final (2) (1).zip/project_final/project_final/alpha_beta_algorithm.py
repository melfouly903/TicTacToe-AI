def alpha_beta_pruning(board, player, alpha=float("-inf"), beta=float("inf")):
    """
    Determines the best move for the current player using the alpha-beta pruning algorithm.

    Args:
        board (list): The current state of the board as a list of 9 elements.
        player (str): The current player, either "X" or "O".
        alpha (float): The best value that the maximizer currently can guarantee at that level or above.
        beta (float): The best value that the minimizer currently can guarantee at that level or above.

    Returns:
        int: The index of the best move for the current player.
    """
    # Get all available moves (empty spots on the board)
    available_moves = [i for i in range(9) if board[i] == " "]

    # Check for terminal states: win for "X", win for "O", or draw
    if check_winner(board, "X"):
        return -1  # "X" wins
    elif check_winner(board, "O"):
        return 1   # "O" wins
    elif not available_moves:
        return 0   # Draw

    best_move = None
    if player == "O":  # Maximizing player
        best_score = float("-inf")
        for move in available_moves:
            board[move] = player  # Make the move
            # Recursively call minimax for the opponent
            score = minimax_with_alpha_beta_pruning(board, "X", alpha, beta)
            board[move] = " "  # Undo the move
            if score > best_score:
                best_score = score
                best_move = move
            alpha = max(alpha, best_score)  # Update alpha
            if alpha >= beta:
                break  # Beta cut-off
    else:  # Minimizing player ("X")
        best_score = float("inf")
        for move in available_moves:
            board[move] = player  # Make the move
            # Recursively call minimax for the opponent
            score = minimax_with_alpha_beta_pruning(board, "O", alpha, beta)
            board[move] = " "  # Undo the move
            if score < best_score:
                best_score = score
                best_move = move
            beta = min(beta, best_score)  # Update beta
            if alpha >= beta:
                break  # Alpha cut-off

    return best_move

def minimax_with_alpha_beta_pruning(board, player, alpha, beta):
    """
    Recursively evaluates the board using minimax with alpha-beta pruning.

    Args:
        board (list): The current state of the board.
        player (str): The current player, either "X" or "O".
        alpha (float): The best value that the maximizer currently can guarantee.
        beta (float): The best value that the minimizer currently can guarantee.

    Returns:
        int: The score of the board state.
    """
    # Get all available moves (empty spots on the board)
    available_moves = [i for i in range(9) if board[i] == " "]

    # Check for terminal states: win for "X", win for "O", or draw
    if check_winner(board, "X"):
        return -1  # "X" wins
    elif check_winner(board, "O"):
        return 1   # "O" wins
    elif not available_moves:
        return 0   # Draw

    if player == "O":  # Maximizing player
        best_score = float("-inf")
        for move in available_moves:
            board[move] = player  # Make the move
            # Recursively call minimax for the opponent
            score = minimax_with_alpha_beta_pruning(board, "X", alpha, beta)
            board[move] = " "  # Undo the move
            best_score = max(best_score, score)
            alpha = max(alpha, best_score)  # Update alpha
            if alpha >= beta:
                break  # Beta cut-off
        return best_score
    else:  # Minimizing player ("X")
        best_score = float("inf")
        for move in available_moves:
            board[move] = player  # Make the move
            # Recursively call minimax for the opponent
            score = minimax_with_alpha_beta_pruning(board, "O", alpha, beta)
            board[move] = " "  # Undo the move
            best_score = min(best_score, score)
            beta = min(beta, best_score)  # Update beta
            if alpha >= beta:
                break  # Alpha cut-off
        return best_score

def check_winner(board, player):
    """
    Checks if the specified player has won the game.

    Args:
        board (list): The current state of the board.
        player (str): The player to check ("X" or "O").

    Returns:
        bool: True if the player has won, False otherwise.
    """
    # All possible winning combinations (rows, columns, diagonals)
    winning_combinations = [
        (0, 1, 2), (3, 4, 5), (6, 7, 8),  # Rows
        (0, 3, 6), (1, 4, 7), (2, 5, 8),  # Columns
        (0, 4, 8), (2, 4, 6)              # Diagonals
    ]

    # Check if all positions in any winning combination are occupied by the player
    for combo in winning_combinations:
        if all(board[i] == player for i in combo):
            return True
    return False









#///////////////////////////////////////////////////////////////////////////////

